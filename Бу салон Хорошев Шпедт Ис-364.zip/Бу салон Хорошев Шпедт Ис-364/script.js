const cars = [
    {
    name: "Toyota Corolla",
    price: "$20,000",
    image: "https://i.pinimg.com/736x/c9/16/40/c91640a82b015cc0c35b07905b272595.jpg",
    description: "Новое состояние, Пробег: 0км."
    },
    {
    name: "Honda Civic",
    price: "$22,500",
    image: "https://avatars.mds.yandex.net/i?id=26c738f5441563f84ea5c5bd388b73ec4ba0e657-10471440-images-thumbs&n=13",
    description: "Новое состояние, Пробег: 0км."
    
    },
    {
    name: "Ford Mustang",
    price: "$30,000",
    image: "https://avatars.mds.yandex.net/i?id=c7a3f64a62be06378c0d50df18dd2077_l-5665039-images-thumbs&n=13",
    description: "Новое состояние, Пробег: 0км."
},
{
    name: "Lada vesta",
    price: "$14,000",
    image: "https://avatars.mds.yandex.net/i?id=c65f34c7d45c60b5ca9988ec695c02f6_l-4472412-images-thumbs&n=13",
    description: "Бу, Пробег: 5.626км."
    },
{
    name: "Kia optima",
    price: "$15,000",
    image: "https://avatars.mds.yandex.net/i?id=136d331b50d751e59a49a6f80ea02967_l-5888429-images-thumbs&n=13",
    description: "Бу, Пробег: 7.180км."
    },
{
    name: "ваз 2114",
    price: "$3,000",
    image: "https://www.barahla.net/images/photo/1/20130421/5969743/big/136649807680019100_big.jpg",
    description: "Бу, Пробег: 57.592км."
    },
{
    name: "ПАЗ 3205",
    price: "$22,500",
    image: "https://admbal.ru/upload/iblock/9b6/9b6a43d661fbeb830849aa60445de20a.jpg",
    description: "Бу, Пробег: 22.461км."
    },
{
    name: "Lamborgini urus",
    price: "$45,000",
    image: "https://yandex-images.clstorage.net/98RHz3K98/d67c4bkrfd5I/KGJzRJdYoW3e7vx8N0QcHavyVhp4QPnAIAJyVcOW3YDr9G4qybcgvawta9Ju_CFTWqzOORDdH48bUeyZChjKvUwn91FzKKE8ml5YvZeFHUlqJme7XcA6o5fFBUYBAH9CuVPvj9xC8Kl9_F_06Ghm152q-J506EhZnPKPTH-9DLhbYHEHgcihXjkdPM2UdB9JWbKXnSt1-mLH5EXVwPJu0UsQjUxu4bDJ2H2cRAjf5fc-Czn_FWgJm1zjjx8d7Y9pSoMid4D6Uz6pbU4t9jSd-Zphh44r12rDNNZGFvGgLbCqsq5-bkJgqYgPjZZazHTVTejKnVRp6SsuUbwPjiztWNlBYjbCmyN8mZxsjpXUzvmpkVZ8eGaaAFfEV5TAgM_iapJfTzzQYog5TZ4XqI90dE2Kyh2U6IiYvmBOLZ_v31l5UvKWIWjhbvkvvpyH9g7a2aElrKu0izIU9IdWsYMckZqx3r2ukKNYy_9ftlv89CZOiwivF1jYa09BTHx87vw6imAiV1MoQmxY3M3sZ0V9WRowltzqZ3mSBKQGZoNxDqDrgZ-8TwLDmBve3zW47vV1T8nJPTZa-Jr_QWxufgzfq6iwgMSTKfA_yPxvT-aVzxuLYRTe-ASpsXdmd1WxANyAqoGeTQ7hMcqYvx7X6Vy2dF25uW7m6yrqLzJv3z-u3ljpcHLH4SqR3crsPJ3H1sybKHCk_LqWOxMXRXQE0lHMwouBLC2MUYCoe3xNtrtvZiWdazv-t_prqX6xTm-vHL6regFApZLKow_Y7TzM91Ys65gwpt-aRRmgdPRF52Fi_wBJQy1NjQPAqog97pVJHnUXrYkrjIVqmhktYl4dHy6PetnDYpVgivGM2NzsPYQHzQvKcSePK5W70ye0tVfB4Z0QSkGODxyQYipJnh3Xq-y3B585y6yESLtanHDvfp9fLKqp8_J1ICogXvkfvn6FZ80YCJJVzgqX-kAUhdYk0",
    description: "Новое состояние, Пробег: 0км."
    
    },
{
    name: "Chevo LAcceti",
    price: "$14,250",
    image: "https://yandex-images.clstorage.net/98RHz3K98/d67c4bkrfd5I/KGJzRJdYoW3e7vx8N0QcHavyVhp4QPnAIAdSZcaWWNW7pEta6ZLw6NyYDrd-qWFTSizOqQVYP3oLEeyZCsiKLTxH5_FzKKE8ml5YvZeFHUlqJmdOWdC5tbDCJJYB4U_zOTIsjb4wUWjp_T72n31FNczd2Q2Xy1koX6IuDl19XDmZEqH1wfpiTsh_vB4EFh04CGJVjpp1mZPGd-RXUcAPYPjAPR5MczOrW15-ljr8hoUsalotNGqYST4ib8ydbFxq-0IiJNAZMT7JTU5-lGZv2Goi1z5ZpomAxtV09qLyDKPJkn5_rdEQmVv9rvZqjpdXfnnLD0eJayt_I498795vemiDQBVD23F_iyw-PKSXTXsJwoQ-alZYcpVkhDXB4B0h-LKcLW3x4agJb6zX28yE1ow6y65H62urv6Luz3_vnVh5QHIU48jh32jf_C7EJJ9pG-BEHRpmK6JGtpUHgtDN44mxT16d0mBamy9tByl-RXd_SUv8ROqpGTwSvjyOzp8JmkFRdxD6MR4an18sZdfsGftTN57Z95jSB2Vnp5KATNO7Q11v7OIhW3q9Dcf5X8X0nFtKr0WoaIsdEJ7NPs6_G5ijcuYyKpON2p7tf_X3Trp6g4XcSKYa0BUGt4ThQj3giTKPT63iIKo7Xv-Vej4EFs3pCa5X2BjYzaFMve69vKrZAXMVc-phjqidjJ335x1oW8CGXOu3qvJXlCUmgWE-sepjnw2M4pLKue5O95n9V3ef2tn_lwqaSJywDf6_Pp0aSbMT5uCbU-zbfb5P5eYdOWtAZixb96jRd0cHleLQD1JZUKzPTiCTqri8DvVqvPRUbavKzafoijquIPxO7O2NaPmBIjdDWXHcKT3szOXXzcgYEYfMCbYpgcaXpeaxkP_i-dPO300iMOgpL6x1qx8HFo9ZCN2VWGoarwLdDV3_PAt58IHnM2nhPGmdPR7EFJ-LGXGH38tVW8DnleR1g",
    description: "Бу, Пробег: 7.346км."
},
{
    name: "Lamborgini Ishak",
    price: "$550",
    image: "https://www.e-education.psu.edu/access/sites/www.e-education.psu.edu.access/files/Images/donkey_web.jpg",
    description: "Бу, Пробег: 19.555км (Топливо: Морковь)."
    }
    ];
    
function displayCars() {
    const carList = document.querySelector('.car-list');
    cars.forEach(car => {
    const carItem = document.createElement('div');
    carItem.classList.add('car-item');
    
    carItem.innerHTML = `
    <img src="${car.image}" alt="${car.name}">
    <h3>${car.name}</h3>
    <p>Price: ${car.price}</p>
    <p>${car.description}</p>
    <button class="buy-btn">Купить</button>
    `;
    
    carList.appendChild(carItem);
    });
    }

    window.onload = displayCars;
