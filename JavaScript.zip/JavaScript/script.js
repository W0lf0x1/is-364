// 1.
document.getElementById('add-field').addEventListener('click', () => {
    const input = document.createElement('input');
    input.type = 'text';
    document.getElementById('dynamic-form').appendChild(input);
});

// 2.
document.getElementById('remove-last').addEventListener('click', () => {
    const list = document.getElementById('list');
    if (list.lastChild) {
        list.removeChild(list.lastChild);
    }
});

// 3.
const images = [
    '/images/08c147e5229b011d0e5c7ee360c22d76.jpg',
    '/images/a5ea6f29a9ab494a6bddbbdbe9aa842679141c2cdb7d401ee088db159d262206.jpg',
    '/images/ab4fba6319c6272b72d29c4bebefd8e2.jpg'
];
let currentIndex = 0;

function updateImage() {
    document.getElementById('gallery').src = images[currentIndex];
}

document.getElementById('next').addEventListener('click', () => {
    currentIndex = (currentIndex + 1) % images.length;
    updateImage();
});

document.getElementById('prev').addEventListener('click', () => {
    currentIndex = (currentIndex - 1 + images.length) % images.length;
    updateImage();
});

// 4.
document.getElementById('show-more').addEventListener('click', () => {
    const text = document.getElementById('more-text');
    text.classList.toggle('hidden');
});

// 5.
const colors = ['red', 'green', 'blue', 'purple'];
let colorIndex = 0;

document.getElementById('change-color').addEventListener('click', () => {
    colorIndex = (colorIndex + 1) % colors.length;
    document.getElementById('text').style.color = colors[colorIndex];
});

// 6.
document.getElementById('email-form').addEventListener('submit', (e) => {
    const email = document.getElementById('email').value;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        alert('Введите правильный email');
        e.preventDefault();
    }
});

// 7.
document.getElementById('header').addEventListener('click', () => {
    const newText = prompt('Введите новый текст для заголовка:');
    if (newText) {
        document.getElementById('header').textContent = newText;
    }
});

// 8.
document.getElementById('show-modal').addEventListener('click', () => {
    alert('Это модальное окно!');
});

// 9.
document.getElementById('hide-text').addEventListener('click', () => {
    document.getElementById('hide-text').style.display = 'none';
});

// 10.
document.getElementById('add-item').addEventListener('click', () => {
    const item = document.getElementById('item-input').value;
    if (item) {
        const li = document.createElement('li');
        li.textContent = item;
        document.getElementById('item-list').appendChild(li);
        document.getElementById('item-input').value = '';
    }
});

// 11.
document.getElementById('sort-button').addEventListener('click', () => {
    const list = document.getElementById('sort-list');
    const items = Array.from(list.children);
    items.reverse().forEach(item => list.appendChild(item));
});

// 12.
const slides = [
    '/images/08c147e5229b011d0e5c7ee360c22d76.jpg',
    '/images/a5ea6f29a9ab494a6bddbbdbe9aa842679141c2cdb7d401ee088db159d262206.jpg',
    '/images/ab4fba6319c6272b72d29c4bebefd8e2.jpg'
];
let currentSlide = 0;

function changeSlide() {
    currentSlide = (currentSlide + 1) % slides.length;
    document.getElementById('slider').src = slides[currentSlide];
}

setInterval(changeSlide, 3000);

// 13.
document.addEventListener('mousemove', (e) => {
    document.getElementById('coordinates').textContent = `Координаты: (${e.clientX}, ${e.clientY})`;
});

// 14.
document.getElementById('add-paragraph').addEventListener('click', () => {
    const p = document.createElement('p');
    p.textContent = 'Новый абзац';
    document.body.appendChild(p);
});

// 15.
window.addEventListener('scroll', () => {
    const scrollPosition = window.scrollY;
    document.body.style.backgroundColor = `rgb(${scrollPosition % 255}, ${scrollPosition % 255}, ${scrollPosition % 255})`;
});
